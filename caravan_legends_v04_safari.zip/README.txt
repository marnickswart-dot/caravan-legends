Caravan Legends 0.4 — Safari/iOS

Upload deze map naar Netlify Drop en open de website in Safari.
Het spel gebruikt zelfgemaakte procedurele 3D-achtige polygonmodellen, geen originele Silkroad-modellen of externe libraries. Offline gebruik kan na een succesvolle eerste online laadbeurt via de service worker; iOS Safari kan cache later wissen.
Versie 0.4 heeft vloeiender opgebouwde personages, ronde schouders, schubbenpantser, gelaagde tempeldaken, animatie en de bestaande combat/XP/inventaris.
Dit is nog geen echte geimporteerde, geskeletteerde 3D-asset pipeline. Niet op een echte iPhone getest.
